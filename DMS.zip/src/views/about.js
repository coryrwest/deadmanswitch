export default () => (
  <div>
    <p><a href='https://github.com/HenrikJoreteg/feather-app'>read more on github</a></p>
  </div>
)
